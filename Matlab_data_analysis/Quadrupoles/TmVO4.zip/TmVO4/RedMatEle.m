function matEle=RedMatEle(J,p)

matEle=1/(2^p)*sqrt(factorial(2*J+p+1)/factorial(2*J-p));